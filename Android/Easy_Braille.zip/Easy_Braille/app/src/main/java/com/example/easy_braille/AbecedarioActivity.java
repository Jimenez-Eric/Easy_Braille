package com.example.easy_braille;

import android.content.Intent;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

public class AbecedarioActivity extends AppCompatActivity {

    private final int DURACION_SPLASH = 1980;

    private WebView webView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_abecedario);

        webView=(WebView)findViewById(R.id.webv2);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setScrollBarStyle(webView.SCROLLBARS_INSIDE_OVERLAY);
        String url = "http://192.168.100.188/";
        webView.loadUrl(url);

    }

    public void goMenu(View view){
       /* Intent menu = new Intent(this, MenuActivity.class);
        startActivity(menu);*/
        onBackPressed();
    }

    public void OnClickA(View view){
        String url = "http://192.168.100.188/A/on";
        webView.loadUrl(url);

        Toast.makeText(this, "A", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.a2);

        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickB(View view){
        String url = "http://192.168.100.188/B/on";
        webView.loadUrl(url);

        Toast.makeText(this, "B", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.b2);

        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickC(View view){
        String url = "http://192.168.100.188/C/on";
        webView.loadUrl(url);

        Toast.makeText(this, "C", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.c2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickD(View view){
        String url = "http://192.168.100.188/D/on";
        webView.loadUrl(url);

        Toast.makeText(this, "D", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.d2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickE(View view){
        String url = "http://192.168.100.188/E/on";
        webView.loadUrl(url);

        Toast.makeText(this, "E", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.e2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickF(View view){
        String url = "http://192.168.100.188/F/on";
        webView.loadUrl(url);

        Toast.makeText(this, "F", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.f2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickG(View view){
        String url = "http://192.168.100.188/G/on";
        webView.loadUrl(url);

        Toast.makeText(this, "G", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.g2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickH(View view){
        String url = "http://192.168.100.188/H/on";
        webView.loadUrl(url);

        Toast.makeText(this, "H", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.h2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickI(View view){
        String url = "http://192.168.100.188/I/on";
        webView.loadUrl(url);

        Toast.makeText(this, "I", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.i22);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickJ(View view){
        String url = "http://192.168.100.188/J/on";
        webView.loadUrl(url);

        Toast.makeText(this, "J", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.j2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickK(View view){
        String url = "http://192.168.100.188/K/on";
        webView.loadUrl(url);

        Toast.makeText(this, "K", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.k2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickL(View view){
        String url = "http://192.168.100.188/L/on";
        webView.loadUrl(url);

        Toast.makeText(this, "L", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.l2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickM(View view){
        String url = "http://192.168.100.188/M/on";
        webView.loadUrl(url);

        Toast.makeText(this, "M", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.m2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickN(View view){
        String url = "http://192.168.100.188/N/on";
        webView.loadUrl(url);

        Toast.makeText(this, "N", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.n2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickO(View view){
        String url = "http://192.168.100.188/O/on";
        webView.loadUrl(url);

        Toast.makeText(this, "O", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.o2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickP(View view){
        String url = "http://192.168.100.188/P/on";
        webView.loadUrl(url);

        Toast.makeText(this, "P", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.p2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickQ(View view){
        String url = "http://192.168.100.188/Q/on";
        webView.loadUrl(url);

        Toast.makeText(this, "Q", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.q2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickR(View view){
        String url = "http://192.168.100.188/R/on";
        webView.loadUrl(url);

        Toast.makeText(this, "R", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.r2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickS(View view){
        String url = "http://192.168.100.188/S/on";
        webView.loadUrl(url);

        Toast.makeText(this, "S", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.s2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickT(View view){
        String url = "http://192.168.100.188/T/on";
        webView.loadUrl(url);

        Toast.makeText(this, "T", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.t2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickU(View view){
        String url = "http://192.168.100.188/U/on";
        webView.loadUrl(url);

        Toast.makeText(this, "U", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.u2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickV(View view){
        String url = "http://192.168.100.188/V/on";
        webView.loadUrl(url);

        Toast.makeText(this, "V", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.v2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickW(View view){
        String url = "http://192.168.100.188/W/on";
        webView.loadUrl(url);

        Toast.makeText(this, "W", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.w2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickX(View view){
        String url = "http://192.168.100.188/X/on";
        webView.loadUrl(url);

        Toast.makeText(this, "X", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.x2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickY(View view){
        String url = "http://192.168.100.188/Y/on";
        webView.loadUrl(url);

        Toast.makeText(this, "Y", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.y2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }

    public void OnClickZ(View view){
        String url = "http://192.168.100.188/Z/on";
        webView.loadUrl(url);

        Toast.makeText(this, "Z", Toast.LENGTH_SHORT).show();

        ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
        letraImg.setImageResource(R.drawable.z2);
        new Handler().postDelayed(new Runnable(){
            public void run(){
                ImageView letraImg = (ImageView) findViewById(R.id.imgABC);
                letraImg.setImageResource(R.drawable.nada);
            };
        }, DURACION_SPLASH);
    }
}
