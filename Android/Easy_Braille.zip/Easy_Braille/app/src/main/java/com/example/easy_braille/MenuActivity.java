package com.example.easy_braille;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }

    public void SiguienteAbecedario(View view){
        Intent abecedario = new Intent(this, AbecedarioActivity.class);
        startActivity(abecedario);
    }

    public void SiguienteAyuda(View view){
        Intent ayuda = new Intent(this, AyudaActivity.class);
        startActivity(ayuda);
    }

    public void SiguienteConexion(View view){
        Intent conexion = new Intent(this, ConexionActivity.class);
        startActivity(conexion);
    }

    public void SiguienteInfo(View view){
        Intent info = new Intent(this, InfoActivity.class);
        startActivity(info);
    }
    public void Salir(View view){
        /*
        Intent salir = new Intent(Intent.ACTION_MAIN);
        salir.addCategory(Intent.CATEGORY_HOME);
        salir.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(salir);*/
        finish();
    }


}