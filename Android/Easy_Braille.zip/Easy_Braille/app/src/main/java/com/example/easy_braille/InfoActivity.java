package com.example.easy_braille;


import android.content.Intent;
import android.graphics.PostProcessor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;

import javax.net.ssl.HttpsURLConnection;

public class InfoActivity extends AppCompatActivity {

    //EditText pin;
    //EditText estadoPin;
    EditText numberPhoneEdit;
    Button OnButton;
    Button OffButton;
    // private RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);


        //pin = (EditText) findViewById(R.id.txtNombre);
        //estado = (EditText) findViewById(R.id.txtApellido);
        //OnButton = (Button) findViewById(R.id.asd);
       // OffButton = (Button) findViewById(R.id.botonsubir);


/*
        firstNameEdit = (EditText) findViewById(R.id.txtNombre);
        lastNameEdit = (EditText) findViewById(R.id.txtApellido);
        numberPhoneEdit = (EditText) findViewById(R.id.txtTelefono);

        getButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                ConnectionClass connection = new ConnectionClass();

                try {
                    String response = connection.execute("https://api.myip.com/").get();
                    //Leeer En Formato Json
                    JSONArray jsonArray = new JSONArray (response);
                    JSONObject jsonObject = jsonArray.getJSONObject(0);

                    String firstName = jsonObject.getString("country");
                    String lastName = jsonObject.getString("country");
                    String numberPhone = jsonObject.getString("cc");

                    firstNameEdit.setText(firstName);
                    lastNameEdit.setText(lastName);
                    numberPhoneEdit.setText(numberPhone);

                } catch (ExecutionException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });

        setButton.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                ConnectionClass connection = new ConnectionClass();

                try {
                    String response = connection.execute("http://192.168.100.188/H}").get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
        });
*/
    }


    public void goMenu(View view) {
       /* Intent menu = new Intent(this, MenuActivity.class);
        startActivity(menu);*/
        onBackPressed();
    }

//
//   private class SendDeviceDetails extends AsyncTask<String, Void, String> {
//
//       @Override
//       protected String doInBackground(String... params) {
//
//           String data = "";
//
//           HttpURLConnection httpURLConnection = null;
//           try {
//
//               httpURLConnection = (HttpURLConnection) new URL(params[0]).openConnection();
//               httpURLConnection.setRequestMethod("POST");
//               httpURLConnection.setRequestProperty("User-Agent", "bot");
//               httpURLConnection.setRequestProperty("Content-Type", "application/json");
//               httpURLConnection.setRequestProperty("Content-Length", "" + data.getBytes().length);
//               httpURLConnection.setRequestProperty("Content-Language", "en-US");
//
//               httpURLConnection.setDoOutput(true);
//
//               DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
//               wr.writeBytes("PostData=" + params[1]);
//               wr.flush();
//               wr.close();
//
//               InputStream in = httpURLConnection.getInputStream();
//               InputStreamReader inputStreamReader = new InputStreamReader(in);
//
//               int inputStreamData = inputStreamReader.read();
//               while (inputStreamData != -1) {
//                   char current = (char) inputStreamData;
//                   inputStreamData = inputStreamReader.read();
//                   data += current;
//               }
//           } catch (Exception e) {
//               e.printStackTrace();
//           } finally {
//               if (httpURLConnection != null) {
//                   httpURLConnection.disconnect();
//               }
//           }
//
//           return data;
//       }
//
//       @Override
//       protected void onPostExecute(String result) {
//           super.onPostExecute(result);
//           Log.e("TAG", result); // this is expecting a response code to be sent from your server upon receiving the POST data
//       }
//   }

// /**************************************************************************************/
// private class SendDeviceDetails extends AsyncTask<String, Void, String> {
//
//     @Override
//     public String doInBackground(String... params) {
//
//         String url = params[0]; // "http://192.168.100.188"
//
//
//		/*
//			// Así tambien podrías formar el JSON
//    	String pinValue = "2";
//    	String estadoValue = "2";
//			String jsonToSend = String.format("{\"pin\":\"%s\",\"value\":\"%s\"}", pinValue, estadoValue);
//		 */
//
//         String jsonToSend = params[1];
//
//         String data = "";
//         HttpURLConnection conn = null;
//         //Toast.makeText(this, data, Toast.LENGTH_SHORT).show();
//
//         try {
//
//
//             URL myUrl = new URL(url);
//
//
//             conn = (HttpURLConnection) myUrl.openConnection();
//
//             conn.setRequestMethod("POST");
//             conn.setRequestProperty("User-Agent", "bot");
//             conn.setRequestProperty("Content-Type", "application/json");
//             conn.setRequestProperty("Content-Length", "" + data.getBytes().length);
//             conn.setRequestProperty("Content-Language", "en-US");
//             conn.setDoOutput(true);
//
//             // Write device information of device to create
//             OutputStream os = conn.getOutputStream();
//             os.write(jsonToSend.getBytes("UTF-8"));
//
//             // Read response
//             InputStream is = conn.getInputStream();
//             InputStreamReader isr = new InputStreamReader(is);
//             BufferedReader br = new BufferedReader(isr);
//
//             String inputLine;
//
//
//             while ((inputLine = br.readLine()) != null) {
//                 data += inputLine;
//             }
//
//             br.close();
//
//             // TODO: parse response and return the message or something
//
//
//         } catch (Exception e) {
//             e.printStackTrace();
//
//         } finally {
//             if (conn != null) {
//                 conn.disconnect();
//             }
//
//         }
//
//         return data;
//     }
// }
    /**********************************************************************************************/
/*
            setButton.setOnClickListener(new View.OnClickListener(){

        @Override
        public void onClick(View view) {
            ConnectionClass connection = new ConnectionClass();

            try {
                String response = connection.execute("http://192.168.100.188/H}").get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        }
    });
    */


 //  public void OnClick(View v) {
 //      JSONObject postData = new JSONObject();
 //      try {
 //          postData.put("pin", "2");
 //          postData.put("estado", "1");
 //          new SendDeviceDetails().execute("http://sensor1.local", postData.toString());
 //
 //
 //          //String pinValue = "2";
 //          //String estadoValue = "0";
 //          // String jsonToSend = String.format("{\"pin\":\"%s\",\"value\":\"%s\"}", pinValue, estadoValue);
 //          // new SendDeviceDetails().execute("http://sensor1.local", jsonToSend);
 //
 //      } catch (JSONException e) {
 //          e.printStackTrace();
 //      }
 //  }
 //
 //  public void OffClick(View v) {
 //      JSONObject postData = new JSONObject();
 //      try {
 //          postData.put("pin", "2");
 //          postData.put("estado", "0");
 //
 //          new SendDeviceDetails().execute("http://sensor1.local/", postData.toString());
 //      } catch (JSONException e) {
 //          e.printStackTrace();
 //      }
 //      //  Toast.makeText(this, postData.toString(), Toast.LENGTH_SHORT).show();
 //  }
 //

/*
    private class SendDeviceDetails extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {

            String data = "";

            HttpURLConnection httpURLConnection = null;
            try {

                httpURLConnection = (HttpURLConnection) new URL(params[0]).openConnection();
                httpURLConnection.setRequestMethod("POST");

                httpURLConnection.setDoOutput(true);

                DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
                wr.writeBytes("PostData=" + params[1]);
                wr.flush();
                wr.close();

                InputStream in = httpURLConnection.getInputStream();
                InputStreamReader inputStreamReader = new InputStreamReader(in);

                int inputStreamData = inputStreamReader.read();
                while (inputStreamData != -1) {
                    char current = (char) inputStreamData;
                    inputStreamData = inputStreamReader.read();
                    data += current;
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (httpURLConnection != null) {
                    httpURLConnection.disconnect();
                }
            }

            return data;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            Log.e("TAG", result); // this is expecting a response code to be sent from your server upon receiving the POST data
        }
    }

*/
   /*
    public void OnLED(View view) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://192.168.100.188/H"));
        startActivity(i);
        //Intent info = new Intent(this, InfoActivity.class);
        //startActivity(info);
        startActivity(menu);
       // onBackPressed();
    }
    public void OffLED(View view) {
        Intent i = new Intent(Intent.ACTION_SENDTO, Uri.parse("http://192.168.100.188/L"));
        startActivity(i);

       // Intent info = new Intent(this, InfoActivity.class);
       // startActivity(info);
        startActivity(menu);
        //onBackPressed();
    }*/

}